#include "widget.h"
#include "ui_widget.h"
#include <QDebug>


Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    setWindowTitle("Server | Data receiver");

    db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("10.10.21.111");
    db.setPort(3306);
    db.setDatabaseName("compnay_project2");
    db.setUserName("beom");
    db.setPassword("123456789");

    m_socket = nullptr;

    m_server.listen(QHostAddress::LocalHost, 5050);

    connect(&m_server,&QTcpServer::newConnection,this,&Widget::gotConnection);

    dong.append("도산동");
    dong.append("동곡동");
    dong.append("본량동");
    dong.append("비아동");
    dong.append("삼도동");
    dong.append("송정1동");
    dong.append("송정2동");
    dong.append("수완동");
    dong.append("신가동");
    dong.append("신창동");
    dong.append("신흥동");
    dong.append("어룡동");
    dong.append("우산동");
    dong.append("운남동");
    dong.append("월곡1동");
    dong.append("월곡2동");
    dong.append("임곡동");
    dong.append("첨단1동");
    dong.append("첨단2동");
    dong.append("평동");
    dong.append("하남동");
}

Widget::~Widget()
{
    if (m_socket)
    {
        qDebug() << "Closing socket : " << (m_socket==nullptr);
        m_socket -> close();
        m_socket -> deleteLater();
    }
    m_server.close();
    delete ui;
}

void Widget::gotConnection()
{
    qDebug() << "Server got new connection";
    m_socket = m_server.nextPendingConnection();
    connect(m_socket,QTcpSocket::readyRead,this,&Widget::readData);
}

void Widget::readData()
{
    QDataStream in(m_socket);

    in.startTransaction(); // 전체 데이터를 가질 때까지 기다렸다가 한번에 읽고 모든 것을 읽을 수 있게 해준다.

    QString recvString;
    in >> recvString;

    if(!in.commitTransaction())
    {
        return; // wait for more data
    }

    ui->textEdit->append(recvString);

    // 인구
    if(recvString == "광산구 전체 인구")
    {
        QDataStream out(m_socket);
        out << this->getPeople();
    }

    // 혼합 시설
    else if(recvString == "혼합 시설"){
        QDataStream out(m_socket);
        out << this->getMix();
    }

    // 상업
    else if(recvString == "부동산업체/산업단지"){
        QDataStream out(m_socket);
        out << this->getCommerce();
    }

    // 편의
    else if(recvString == "편의 시설"){
        QDataStream out(m_socket);
        out << this->getConvenience();
    }

    // 음식
    else if(recvString == "음식 시설"){
        QDataStream out(m_socket);
        out << this->getRestaurant();
    }

    // 편의점
    else if(recvString == "동별 편의점"){
        QDataStream out(m_socket);
        out << this->getConveniBrand();
    }

    // 종합
    else if(recvString == "종합 결과"){
        QDataStream out(m_socket);
        out << this->getAll();
    }

    // 예외
    else{
        QString gogogo;
        gogogo.append("테이블 선택;0;0");
        QDataStream out(m_socket);
        out << gogogo;
    }
}

QString Widget::getPeople(){
    db.open();

    if (db.open())
    {
        qDebug() << "db연결 성공~~";
    }
    else
    {
        qDebug() << "db연결 실패 ㅠㅠ,,";
    }

    QSqlQuery query;
    QString qry;
    QList<QString> a;
    QString gogogo;
    QString h_len;  // 열 개수
    QString c_len;  // 행 개수

    query.exec("SELECT count(Dong) from compnay_project2.all_people");    //해당 조회의 행 숫자가 몇개인지 알아내는 쿼리문
    while (query.next()) {
        h_len = query.value(0).toString();

    }
    query.exec("SELECT COUNT(*) FROM information_schema.columns WHERE table_name='all_people'"); //해당 조회의 칼럼값이 몇개인지 알아내는 쿼리문
    while (query.next()) {
        c_len = query.value(0).toString();
    }

    qry = "SELECT * FROM compnay_project2.all_people";
    query.exec(qry);

    while(query.next())
        {
            a.append(query.value(0).toString());
            a.append(query.value(1).toString());
            a.append(query.value(2).toString());
            a.append(query.value(3).toString());
            a.append(query.value(4).toString());
        }

    gogogo.append("광산구 전체 인구");
    gogogo.append(";");
    gogogo.append(h_len);
    gogogo.append(";");
    gogogo.append(c_len);

    for (int i =0;i<a.length(); i++){
        gogogo.append(";");
        gogogo.append(a[i]);
    }

    db.close();

    return gogogo;
}

QString Widget::getCommerce(){
    db.open();

    if (db.open())
    {
        qDebug() << "db연결 성공~~";
    }
    else
    {
        qDebug() << "db연결 실패 ㅠㅠ,,";
    }

    QSqlQuery query;
    QString qry;
    QString gogogo;

    gogogo.append("부동산업체/산업단지;22;2;");
    qry = "SELECT count(*) from compnay_project2.commerce";
    query.exec(qry);
    query.next();
    gogogo.append("계;");
    gogogo.append(query.value(0).toString());

    for(int i = 0; i < 21; i++){
        gogogo.append(";");
        qry = "SELECT count(*) from compnay_project2.commerce where Dong = '" + dong[i] + "'";
        query.exec(qry);
        query.next();
        gogogo.append(dong[i] + ";");
        gogogo.append(query.value(0).toString());
    }

    db.close();

    return gogogo;
}

QString Widget::getConvenience(){
    db.open();

    if (db.open())
    {
        qDebug() << "db연결 성공~~";
    }
    else
    {
        qDebug() << "db연결 실패 ㅠㅠ,,";
    }

    QSqlQuery query;
    QString qry;
    QString gogogo;

    gogogo.append("편의 시설;22;2;");
    qry = "SELECT count(*) from compnay_project2.convenience";
    query.exec(qry);
    query.next();
    gogogo.append("계;");
    gogogo.append(query.value(0).toString());

    for(int i = 0; i < 21; i++){
        gogogo.append(";");
        qry = "SELECT count(*) from compnay_project2.convenience where Dong = '" + dong[i] + "'";
        query.exec(qry);
        query.next();
        gogogo.append(dong[i] + ";");
        gogogo.append(query.value(0).toString());
    }

    db.close();

    return gogogo;
}

QString Widget::getRestaurant(){
    db.open();

    if (db.open())
    {
        qDebug() << "db연결 성공~~";
    }
    else
    {
        qDebug() << "db연결 실패 ㅠㅠ,,";
    }

    QSqlQuery query;
    QString qry;
    QString gogogo;

    gogogo.append("음식 시설;22;2;");
    qry = "SELECT count(*) from compnay_project2.restaurant";
    query.exec(qry);
    query.next();
    gogogo.append("계;");
    gogogo.append(query.value(0).toString());

    for(int i = 0; i < 21; i++){
        gogogo.append(";");
        qry = "SELECT count(*) from compnay_project2.restaurant where Dong = '" + dong[i] + "'";
        query.exec(qry);
        query.next();
        gogogo.append(dong[i] + ";");
        gogogo.append(query.value(0).toString());
    }

    db.close();

    return gogogo;
}

QString Widget::getConveniBrand(){
    db.open();

    if (db.open())
    {
        qDebug() << "db연결 성공~~";
    }
    else
    {
        qDebug() << "db연결 실패 ㅠㅠ,,";
    }

    QSqlQuery query;
    QString qry;
    QString gogogo;

    gogogo.append("동별 편의점;22;2;");
    qry = "SELECT count(*) from compnay_project2.conveni_brand";
    query.exec(qry);
    query.next();
    gogogo.append("계;");
    gogogo.append(query.value(0).toString());

    for(int i = 0; i < 21; i++){
        gogogo.append(";");
        qry = "SELECT count(*) from compnay_project2.conveni_brand where Dong = '" + dong[i] + "'";
        query.exec(qry);
        query.next();
        gogogo.append(dong[i] + ";");
        gogogo.append(query.value(0).toString());
    }

    db.close();

    return gogogo;
}

QString Widget::getMix(){
    db.open();

    QSqlQuery query;
    QString qry;
    QString gogogo;

    gogogo.append("혼합 시설;22;5;");
    qry = "SELECT count(*) as welfare, (select count(*) from compnay_project2.medical) as medical, "
          "(select count(*) from compnay_project2.education) as education,"
          "(select count(*) from compnay_project2.apart_offices) as apart_offices FROM compnay_project2.welfare;";
    query.exec(qry);
    query.next();
    gogogo.append("계");
    for(int i = 0; i < 4; i++){
        gogogo.append(";");
        gogogo.append(query.value(i).toString());
    }

    for(int i = 0; i < 21; i++){
        qry = "SELECT count(*) as welfare, (select count(*) from compnay_project2.medical where Dong = '" + dong[i] + "') as medical, "
            "(select count(*) from compnay_project2.education where Dong = '" + dong[i] + "') as education,"
            "(select count(*) from compnay_project2.apart_offices where Serv_dong = '" + dong[i] + "') as apart_offices "
            "FROM compnay_project2.welfare where Dong = '" + dong[i] + "';";
        query.exec(qry);
        query.next();
        gogogo.append(";");
        gogogo.append(dong[i]);
        for(int j = 0; j < 4; j++){
            gogogo.append(";");
            gogogo.append(query.value(j).toString());
        }
    }

    db.close();

    qDebug()<<gogogo;

    return gogogo;
}

QString Widget::getAll(){
    QStringList people_data = this->getPeople().split(";");
    QStringList commerce_data = this->getCommerce().split(";");
    QStringList convenience_data = this->getConvenience().split(";");
    QStringList restaurant_data = this->getRestaurant().split(";");
    QStringList mix_data = this->getMix().split(";");
//    QStringList brand_data = this->getConveniBrand().split(";");

    for(int i = 0; i < 3; i++){
        people_data.remove(0);
        commerce_data.remove(0);
        convenience_data.remove(0);
        restaurant_data.remove(0);
        mix_data.remove(0);
//        brand_data.remove(0);
    }

    QString all_score;
    all_score.append("종합 결과;21;6");

    for(int i = 1; i < 22; i++){
        all_score.append(";" + dong[i-1]);

        double people_score = (people_data[(i*5)+1].toDouble() / people_data[1].toDouble() * 100) / (people_data[(i*5)+4].toDouble() / people_data[4].toDouble() * 100);
        all_score.append(";" + QString::number(people_score).left(3));

        double commerce_score = (commerce_data[(i*2)+1].toDouble() / commerce_data[1].toDouble() * 100) / (commerce_data[1].toDouble() / 14290 * 100);
        all_score.append(";" + QString::number(commerce_score).left(3));

        double convenience_score = (convenience_data[(i*2)+1].toDouble() / convenience_data[1].toDouble() * 100) / (convenience_data[1].toDouble() / 14290 * 100);
        all_score.append(";" + QString::number(convenience_score).left(3));

        double restaurant_score = (restaurant_data[(i*2)+1].toDouble() / restaurant_data[1].toDouble() * 100) / (restaurant_data[1].toDouble() / 14290 * 100);
        all_score.append(";" + QString::number(restaurant_score).left(3));

        double mix_score = ((mix_data[(i*5)+1].toDouble()+mix_data[(i*5)+2].toDouble()+mix_data[(i*5)+3].toDouble()+mix_data[(i*5)+4].toDouble())
                        / (mix_data[1].toDouble()+mix_data[2].toDouble()+mix_data[3].toDouble()+mix_data[4].toDouble()) * 100)
                        / ((mix_data[1].toDouble()+mix_data[2].toDouble()+mix_data[3].toDouble()+mix_data[4].toDouble()) / 14290 * 100);
        all_score.append(";" + QString::number(mix_score).left(3));

//        double brand_score = (brand_data[(i*2)+1].toDouble() / brand_data[1].toDouble() * 100) / (brand_data[1].toDouble() / 14290 * 100);
//        all_score.append(";" + QString::number(brand_score).left(3));
    }

    qDebug()<<all_score;

    return all_score;
}
